
package net.mcreator.newores.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.Rarity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.newores.init.NewOresModItems;
import net.mcreator.newores.init.NewOresModFluids;
import net.mcreator.newores.init.NewOresModBlocks;

public abstract class SmoltenemeraldFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(NewOresModFluids.SMOLTENEMERALD,
			NewOresModFluids.FLOWING_SMOLTENEMERALD,
			FluidAttributes.builder(new ResourceLocation("new_ores:blocks/smolten"), new ResourceLocation("new_ores:blocks/smolten"))

					.rarity(Rarity.RARE))
			.explosionResistance(100f)

			.tickRate(7).levelDecreasePerBlock(8).slopeFindDistance(5).bucket(NewOresModItems.SMOLTENEMERALD_BUCKET)
			.block(() -> (LiquidBlock) NewOresModBlocks.SMOLTENEMERALD.get());

	private SmoltenemeraldFluid() {
		super(PROPERTIES);
	}

	@Override
	public Vec3 getFlow(BlockGetter world, BlockPos pos, FluidState fluidstate) {
		return super.getFlow(world, pos, fluidstate).scale(2);
	}

	public static class Source extends SmoltenemeraldFluid {
		public Source() {
			super();
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends SmoltenemeraldFluid {
		public Flowing() {
			super();
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
