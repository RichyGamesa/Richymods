
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.newores.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.newores.client.renderer.SharkRenderer;
import net.mcreator.newores.client.renderer.FireflyRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class NewOresModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(NewOresModEntities.EMERALDARROW.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(NewOresModEntities.FIREFLY.get(), FireflyRenderer::new);
		event.registerEntityRenderer(NewOresModEntities.SHARK.get(), SharkRenderer::new);
	}
}
