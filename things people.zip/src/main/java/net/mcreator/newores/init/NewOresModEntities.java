
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.newores.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.newores.entity.SharkEntity;
import net.mcreator.newores.entity.FireflyEntity;
import net.mcreator.newores.entity.EmeraldarrowEntity;
import net.mcreator.newores.NewOresMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class NewOresModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, NewOresMod.MODID);
	public static final RegistryObject<EntityType<EmeraldarrowEntity>> EMERALDARROW = register("projectile_emeraldarrow",
			EntityType.Builder.<EmeraldarrowEntity>of(EmeraldarrowEntity::new, MobCategory.MISC).setCustomClientFactory(EmeraldarrowEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<FireflyEntity>> FIREFLY = register("firefly",
			EntityType.Builder.<FireflyEntity>of(FireflyEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(FireflyEntity::new)

					.sized(1f, 1f));
	public static final RegistryObject<EntityType<SharkEntity>> SHARK = register("shark",
			EntityType.Builder.<SharkEntity>of(SharkEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(SharkEntity::new)

					.sized(2.5f, 2.4f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			FireflyEntity.init();
			SharkEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(FIREFLY.get(), FireflyEntity.createAttributes().build());
		event.put(SHARK.get(), SharkEntity.createAttributes().build());
	}
}
