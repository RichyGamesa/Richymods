
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.newores.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.newores.item.SwordemeItem;
import net.mcreator.newores.item.SmoltenemeraldItem;
import net.mcreator.newores.item.SmolssItem;
import net.mcreator.newores.item.ShovelemeraldItem;
import net.mcreator.newores.item.RubySwordItem;
import net.mcreator.newores.item.RubyShovelItem;
import net.mcreator.newores.item.RubyPickaxeItem;
import net.mcreator.newores.item.RubyItem;
import net.mcreator.newores.item.RubyHoeItem;
import net.mcreator.newores.item.RubyAxeItem;
import net.mcreator.newores.item.RubyArmorItem;
import net.mcreator.newores.item.Ho3Item;
import net.mcreator.newores.item.EmeraldshardItem;
import net.mcreator.newores.item.EmeraldpickItem;
import net.mcreator.newores.item.EmeraldaxeItem;
import net.mcreator.newores.item.EmeraldarrowsItem;
import net.mcreator.newores.item.EmeraldarrowItem;
import net.mcreator.newores.item.EmeraldarmorItem;
import net.mcreator.newores.item.EMENUGGETItem;
import net.mcreator.newores.item.BluestoneSwordItem;
import net.mcreator.newores.item.BluestoneShovelItem;
import net.mcreator.newores.item.BluestonePickaxeItem;
import net.mcreator.newores.item.BluestoneHoeItem;
import net.mcreator.newores.item.BluestoneDustItem;
import net.mcreator.newores.item.BluestoneAxeItem;
import net.mcreator.newores.item.BluestoneArmorItem;
import net.mcreator.newores.item.AtherItem;
import net.mcreator.newores.item.AquadyeItem;
import net.mcreator.newores.item.AetherItem;
import net.mcreator.newores.NewOresMod;

public class NewOresModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NewOresMod.MODID);
	public static final RegistryObject<Item> SWORDEME = REGISTRY.register("swordeme", () -> new SwordemeItem());
	public static final RegistryObject<Item> EMENUGGET = REGISTRY.register("emenugget", () -> new EMENUGGETItem());
	public static final RegistryObject<Item> EMERALDARMOR_HELMET = REGISTRY.register("emeraldarmor_helmet", () -> new EmeraldarmorItem.Helmet());
	public static final RegistryObject<Item> EMERALDARMOR_CHESTPLATE = REGISTRY.register("emeraldarmor_chestplate",
			() -> new EmeraldarmorItem.Chestplate());
	public static final RegistryObject<Item> EMERALDARMOR_LEGGINGS = REGISTRY.register("emeraldarmor_leggings",
			() -> new EmeraldarmorItem.Leggings());
	public static final RegistryObject<Item> EMERALDARMOR_BOOTS = REGISTRY.register("emeraldarmor_boots", () -> new EmeraldarmorItem.Boots());
	public static final RegistryObject<Item> EMERALDSHARD = REGISTRY.register("emeraldshard", () -> new EmeraldshardItem());
	public static final RegistryObject<Item> EMERALDARROWS = REGISTRY.register("emeraldarrows", () -> new EmeraldarrowsItem());
	public static final RegistryObject<Item> EMERALDARROW = REGISTRY.register("emeraldarrow", () -> new EmeraldarrowItem());
	public static final RegistryObject<Item> EMERALDAXE = REGISTRY.register("emeraldaxe", () -> new EmeraldaxeItem());
	public static final RegistryObject<Item> EMERALDPICK = REGISTRY.register("emeraldpick", () -> new EmeraldpickItem());
	public static final RegistryObject<Item> HO_3 = REGISTRY.register("ho_3", () -> new Ho3Item());
	public static final RegistryObject<Item> SHOVELEMERALD = REGISTRY.register("shovelemerald", () -> new ShovelemeraldItem());
	public static final RegistryObject<Item> SMOLTENEMERALD_BUCKET = REGISTRY.register("smoltenemerald_bucket", () -> new SmoltenemeraldItem());
	public static final RegistryObject<Item> SMOLSS = REGISTRY.register("smolss", () -> new SmolssItem());
	public static final RegistryObject<Item> FIREFLY = REGISTRY.register("firefly_spawn_egg", () -> new ForgeSpawnEggItem(NewOresModEntities.FIREFLY,
			-399872, -16777216, new Item.Properties().tab(NewOresModTabs.TAB_VORREICHEFOSSE_119)));
	public static final RegistryObject<Item> SHARK = REGISTRY.register("shark_spawn_egg",
			() -> new ForgeSpawnEggItem(NewOresModEntities.SHARK, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> RUBY = REGISTRY.register("ruby", () -> new RubyItem());
	public static final RegistryObject<Item> RUBY_ORE = block(NewOresModBlocks.RUBY_ORE, NewOresModTabs.TAB_RUBYS);
	public static final RegistryObject<Item> RUBY_BLOCK = block(NewOresModBlocks.RUBY_BLOCK, NewOresModTabs.TAB_RUBYS);
	public static final RegistryObject<Item> RUBY_PICKAXE = REGISTRY.register("ruby_pickaxe", () -> new RubyPickaxeItem());
	public static final RegistryObject<Item> RUBY_AXE = REGISTRY.register("ruby_axe", () -> new RubyAxeItem());
	public static final RegistryObject<Item> RUBY_SWORD = REGISTRY.register("ruby_sword", () -> new RubySwordItem());
	public static final RegistryObject<Item> RUBY_SHOVEL = REGISTRY.register("ruby_shovel", () -> new RubyShovelItem());
	public static final RegistryObject<Item> RUBY_HOE = REGISTRY.register("ruby_hoe", () -> new RubyHoeItem());
	public static final RegistryObject<Item> RUBY_ARMOR_HELMET = REGISTRY.register("ruby_armor_helmet", () -> new RubyArmorItem.Helmet());
	public static final RegistryObject<Item> RUBY_ARMOR_CHESTPLATE = REGISTRY.register("ruby_armor_chestplate", () -> new RubyArmorItem.Chestplate());
	public static final RegistryObject<Item> RUBY_ARMOR_LEGGINGS = REGISTRY.register("ruby_armor_leggings", () -> new RubyArmorItem.Leggings());
	public static final RegistryObject<Item> RUBY_ARMOR_BOOTS = REGISTRY.register("ruby_armor_boots", () -> new RubyArmorItem.Boots());
	public static final RegistryObject<Item> BLUESTONE_DUST = REGISTRY.register("bluestone_dust", () -> new BluestoneDustItem());
	public static final RegistryObject<Item> BLUESTONE_ORE = block(NewOresModBlocks.BLUESTONE_ORE, NewOresModTabs.TAB_BLUESTONE);
	public static final RegistryObject<Item> BLUESTONE_BLOCK = block(NewOresModBlocks.BLUESTONE_BLOCK, NewOresModTabs.TAB_BLUESTONE);
	public static final RegistryObject<Item> BLUESTONE_PICKAXE = REGISTRY.register("bluestone_pickaxe", () -> new BluestonePickaxeItem());
	public static final RegistryObject<Item> BLUESTONE_AXE = REGISTRY.register("bluestone_axe", () -> new BluestoneAxeItem());
	public static final RegistryObject<Item> BLUESTONE_SWORD = REGISTRY.register("bluestone_sword", () -> new BluestoneSwordItem());
	public static final RegistryObject<Item> BLUESTONE_SHOVEL = REGISTRY.register("bluestone_shovel", () -> new BluestoneShovelItem());
	public static final RegistryObject<Item> BLUESTONE_HOE = REGISTRY.register("bluestone_hoe", () -> new BluestoneHoeItem());
	public static final RegistryObject<Item> BLUESTONE_ARMOR_HELMET = REGISTRY.register("bluestone_armor_helmet",
			() -> new BluestoneArmorItem.Helmet());
	public static final RegistryObject<Item> BLUESTONE_ARMOR_CHESTPLATE = REGISTRY.register("bluestone_armor_chestplate",
			() -> new BluestoneArmorItem.Chestplate());
	public static final RegistryObject<Item> BLUESTONE_ARMOR_LEGGINGS = REGISTRY.register("bluestone_armor_leggings",
			() -> new BluestoneArmorItem.Leggings());
	public static final RegistryObject<Item> BLUESTONE_ARMOR_BOOTS = REGISTRY.register("bluestone_armor_boots", () -> new BluestoneArmorItem.Boots());
	public static final RegistryObject<Item> AETHER_BUCKET = REGISTRY.register("aether_bucket", () -> new AetherItem());
	public static final RegistryObject<Item> ATHER = REGISTRY.register("ather", () -> new AtherItem());
	public static final RegistryObject<Item> RED_PLANKS_LOG = block(NewOresModBlocks.RED_PLANKS_LOG, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> RED_PLANKS_PLANKS = block(NewOresModBlocks.RED_PLANKS_PLANKS, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> RED_PLANKS_LEAVES = block(NewOresModBlocks.RED_PLANKS_LEAVES, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> RED_PLANKS_STAIRS = block(NewOresModBlocks.RED_PLANKS_STAIRS, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> RED_PLANKS_SLAB = block(NewOresModBlocks.RED_PLANKS_SLAB, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> RED_PLANKS_FENCE = block(NewOresModBlocks.RED_PLANKS_FENCE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> RED_PLANKS_FENCE_GATE = block(NewOresModBlocks.RED_PLANKS_FENCE_GATE, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> RED_PLANKS_PRESSURE_PLATE = block(NewOresModBlocks.RED_PLANKS_PRESSURE_PLATE,
			CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> RED_PLANKS_BUTTON = block(NewOresModBlocks.RED_PLANKS_BUTTON, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> CYAN_WOOD = block(NewOresModBlocks.CYAN_WOOD, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> CYAN_LOG = block(NewOresModBlocks.CYAN_LOG, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> CYAN_PLANKS = block(NewOresModBlocks.CYAN_PLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> CYAN_LEAVES = block(NewOresModBlocks.CYAN_LEAVES, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> CYAN_STAIRS = block(NewOresModBlocks.CYAN_STAIRS, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> CYAN_SLAB = block(NewOresModBlocks.CYAN_SLAB, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> CYAN_FENCE = block(NewOresModBlocks.CYAN_FENCE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> CYAN_FENCE_GATE = block(NewOresModBlocks.CYAN_FENCE_GATE, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> CYAN_PRESSURE_PLATE = block(NewOresModBlocks.CYAN_PRESSURE_PLATE, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> CYAN_BUTTON = block(NewOresModBlocks.CYAN_BUTTON, NewOresModTabs.TAB_SSSSS);
	public static final RegistryObject<Item> PURPLEPLAN = block(NewOresModBlocks.PURPLEPLAN, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> REDPLANKS = block(NewOresModBlocks.REDPLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> YELLOW_PLANKS = block(NewOresModBlocks.YELLOW_PLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> GREENPLANKS = block(NewOresModBlocks.GREENPLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> PLANK = block(NewOresModBlocks.PLANK, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> AQUA_PLANKS = block(NewOresModBlocks.AQUA_PLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> BLUE_PLANKS = block(NewOresModBlocks.BLUE_PLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> PINKPLANKS = block(NewOresModBlocks.PINKPLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> BROWNPLANKS = block(NewOresModBlocks.BROWNPLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> GREENPLANKSS = block(NewOresModBlocks.GREENPLANKSS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> AQUADYE = REGISTRY.register("aquadye", () -> new AquadyeItem());
	public static final RegistryObject<Item> BLACKPLANKS = block(NewOresModBlocks.BLACKPLANKS, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> GREYPLANK = block(NewOresModBlocks.GREYPLANK, NewOresModTabs.TAB_PLANKS);
	public static final RegistryObject<Item> WHITEPLANK = block(NewOresModBlocks.WHITEPLANK, NewOresModTabs.TAB_PLANKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
