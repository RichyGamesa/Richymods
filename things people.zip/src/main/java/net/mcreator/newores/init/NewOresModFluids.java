
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.newores.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.newores.fluid.SmoltenemeraldFluid;
import net.mcreator.newores.fluid.AetherFluid;
import net.mcreator.newores.NewOresMod;

public class NewOresModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, NewOresMod.MODID);
	public static final RegistryObject<Fluid> SMOLTENEMERALD = REGISTRY.register("smoltenemerald", () -> new SmoltenemeraldFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_SMOLTENEMERALD = REGISTRY.register("flowing_smoltenemerald",
			() -> new SmoltenemeraldFluid.Flowing());
	public static final RegistryObject<Fluid> AETHER = REGISTRY.register("aether", () -> new AetherFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_AETHER = REGISTRY.register("flowing_aether", () -> new AetherFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(SMOLTENEMERALD.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_SMOLTENEMERALD.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(AETHER.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_AETHER.get(), renderType -> renderType == RenderType.translucent());
		}
	}
}
