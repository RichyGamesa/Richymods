
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.newores.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class NewOresModTabs {
	public static CreativeModeTab TAB_SSSSS;
	public static CreativeModeTab TAB_VORREICHEFOSSE_119;
	public static CreativeModeTab TAB_RUBYS;
	public static CreativeModeTab TAB_BLUESTONE;
	public static CreativeModeTab TAB_PLANKS;

	public static void load() {
		TAB_SSSSS = new CreativeModeTab("tabsssss") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(Items.EMERALD);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
		TAB_VORREICHEFOSSE_119 = new CreativeModeTab("tabvorreichefosse_119") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(Blocks.BARRIER);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
		TAB_RUBYS = new CreativeModeTab("tabrubys") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(NewOresModItems.RUBY.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
		TAB_BLUESTONE = new CreativeModeTab("tabbluestone") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(NewOresModItems.BLUESTONE_DUST.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_PLANKS = new CreativeModeTab("tabplanks") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(Blocks.OAK_PLANKS);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
	}
}
