
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.newores.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.newores.block.YellowPlanksBlock;
import net.mcreator.newores.block.WhiteplankBlock;
import net.mcreator.newores.block.SmoltenemeraldBlock;
import net.mcreator.newores.block.RubyOreBlock;
import net.mcreator.newores.block.RubyBlockBlock;
import net.mcreator.newores.block.RedplanksBlock;
import net.mcreator.newores.block.Red_planksStairsBlock;
import net.mcreator.newores.block.Red_planksSlabBlock;
import net.mcreator.newores.block.Red_planksPressurePlateBlock;
import net.mcreator.newores.block.Red_planksPlanksBlock;
import net.mcreator.newores.block.Red_planksLogBlock;
import net.mcreator.newores.block.Red_planksLeavesBlock;
import net.mcreator.newores.block.Red_planksFenceGateBlock;
import net.mcreator.newores.block.Red_planksFenceBlock;
import net.mcreator.newores.block.Red_planksButtonBlock;
import net.mcreator.newores.block.PurpleplanBlock;
import net.mcreator.newores.block.PinkplanksBlock;
import net.mcreator.newores.block.PLANKBlock;
import net.mcreator.newores.block.GreyplankBlock;
import net.mcreator.newores.block.GreenplankssBlock;
import net.mcreator.newores.block.GreenplanksBlock;
import net.mcreator.newores.block.CyanWoodBlock;
import net.mcreator.newores.block.CyanStairsBlock;
import net.mcreator.newores.block.CyanSlabBlock;
import net.mcreator.newores.block.CyanPressurePlateBlock;
import net.mcreator.newores.block.CyanPlanksBlock;
import net.mcreator.newores.block.CyanLogBlock;
import net.mcreator.newores.block.CyanLeavesBlock;
import net.mcreator.newores.block.CyanFenceGateBlock;
import net.mcreator.newores.block.CyanFenceBlock;
import net.mcreator.newores.block.CyanButtonBlock;
import net.mcreator.newores.block.BrownplanksBlock;
import net.mcreator.newores.block.BluestoneOreBlock;
import net.mcreator.newores.block.BluestoneBlockBlock;
import net.mcreator.newores.block.BluePlanksBlock;
import net.mcreator.newores.block.BlackplanksBlock;
import net.mcreator.newores.block.AtherPortalBlock;
import net.mcreator.newores.block.AquaPlanksBlock;
import net.mcreator.newores.block.AetherBlock;
import net.mcreator.newores.NewOresMod;

public class NewOresModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, NewOresMod.MODID);
	public static final RegistryObject<Block> SMOLTENEMERALD = REGISTRY.register("smoltenemerald", () -> new SmoltenemeraldBlock());
	public static final RegistryObject<Block> RUBY_ORE = REGISTRY.register("ruby_ore", () -> new RubyOreBlock());
	public static final RegistryObject<Block> RUBY_BLOCK = REGISTRY.register("ruby_block", () -> new RubyBlockBlock());
	public static final RegistryObject<Block> BLUESTONE_ORE = REGISTRY.register("bluestone_ore", () -> new BluestoneOreBlock());
	public static final RegistryObject<Block> BLUESTONE_BLOCK = REGISTRY.register("bluestone_block", () -> new BluestoneBlockBlock());
	public static final RegistryObject<Block> AETHER = REGISTRY.register("aether", () -> new AetherBlock());
	public static final RegistryObject<Block> ATHER_PORTAL = REGISTRY.register("ather_portal", () -> new AtherPortalBlock());
	public static final RegistryObject<Block> RED_PLANKS_LOG = REGISTRY.register("red_planks_log", () -> new Red_planksLogBlock());
	public static final RegistryObject<Block> RED_PLANKS_PLANKS = REGISTRY.register("red_planks_planks", () -> new Red_planksPlanksBlock());
	public static final RegistryObject<Block> RED_PLANKS_LEAVES = REGISTRY.register("red_planks_leaves", () -> new Red_planksLeavesBlock());
	public static final RegistryObject<Block> RED_PLANKS_STAIRS = REGISTRY.register("red_planks_stairs", () -> new Red_planksStairsBlock());
	public static final RegistryObject<Block> RED_PLANKS_SLAB = REGISTRY.register("red_planks_slab", () -> new Red_planksSlabBlock());
	public static final RegistryObject<Block> RED_PLANKS_FENCE = REGISTRY.register("red_planks_fence", () -> new Red_planksFenceBlock());
	public static final RegistryObject<Block> RED_PLANKS_FENCE_GATE = REGISTRY.register("red_planks_fence_gate",
			() -> new Red_planksFenceGateBlock());
	public static final RegistryObject<Block> RED_PLANKS_PRESSURE_PLATE = REGISTRY.register("red_planks_pressure_plate",
			() -> new Red_planksPressurePlateBlock());
	public static final RegistryObject<Block> RED_PLANKS_BUTTON = REGISTRY.register("red_planks_button", () -> new Red_planksButtonBlock());
	public static final RegistryObject<Block> CYAN_WOOD = REGISTRY.register("cyan_wood", () -> new CyanWoodBlock());
	public static final RegistryObject<Block> CYAN_LOG = REGISTRY.register("cyan_log", () -> new CyanLogBlock());
	public static final RegistryObject<Block> CYAN_PLANKS = REGISTRY.register("cyan_planks", () -> new CyanPlanksBlock());
	public static final RegistryObject<Block> CYAN_LEAVES = REGISTRY.register("cyan_leaves", () -> new CyanLeavesBlock());
	public static final RegistryObject<Block> CYAN_STAIRS = REGISTRY.register("cyan_stairs", () -> new CyanStairsBlock());
	public static final RegistryObject<Block> CYAN_SLAB = REGISTRY.register("cyan_slab", () -> new CyanSlabBlock());
	public static final RegistryObject<Block> CYAN_FENCE = REGISTRY.register("cyan_fence", () -> new CyanFenceBlock());
	public static final RegistryObject<Block> CYAN_FENCE_GATE = REGISTRY.register("cyan_fence_gate", () -> new CyanFenceGateBlock());
	public static final RegistryObject<Block> CYAN_PRESSURE_PLATE = REGISTRY.register("cyan_pressure_plate", () -> new CyanPressurePlateBlock());
	public static final RegistryObject<Block> CYAN_BUTTON = REGISTRY.register("cyan_button", () -> new CyanButtonBlock());
	public static final RegistryObject<Block> PURPLEPLAN = REGISTRY.register("purpleplan", () -> new PurpleplanBlock());
	public static final RegistryObject<Block> REDPLANKS = REGISTRY.register("redplanks", () -> new RedplanksBlock());
	public static final RegistryObject<Block> YELLOW_PLANKS = REGISTRY.register("yellow_planks", () -> new YellowPlanksBlock());
	public static final RegistryObject<Block> GREENPLANKS = REGISTRY.register("greenplanks", () -> new GreenplanksBlock());
	public static final RegistryObject<Block> PLANK = REGISTRY.register("plank", () -> new PLANKBlock());
	public static final RegistryObject<Block> AQUA_PLANKS = REGISTRY.register("aqua_planks", () -> new AquaPlanksBlock());
	public static final RegistryObject<Block> BLUE_PLANKS = REGISTRY.register("blue_planks", () -> new BluePlanksBlock());
	public static final RegistryObject<Block> PINKPLANKS = REGISTRY.register("pinkplanks", () -> new PinkplanksBlock());
	public static final RegistryObject<Block> BROWNPLANKS = REGISTRY.register("brownplanks", () -> new BrownplanksBlock());
	public static final RegistryObject<Block> GREENPLANKSS = REGISTRY.register("greenplankss", () -> new GreenplankssBlock());
	public static final RegistryObject<Block> BLACKPLANKS = REGISTRY.register("blackplanks", () -> new BlackplanksBlock());
	public static final RegistryObject<Block> GREYPLANK = REGISTRY.register("greyplank", () -> new GreyplankBlock());
	public static final RegistryObject<Block> WHITEPLANK = REGISTRY.register("whiteplank", () -> new WhiteplankBlock());
}
