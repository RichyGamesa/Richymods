
package net.mcreator.newores.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

import net.mcreator.newores.init.NewOresModTabs;

public class EmeraldshardItem extends Item {
	public EmeraldshardItem() {
		super(new Item.Properties().tab(NewOresModTabs.TAB_SSSSS).stacksTo(64).rarity(Rarity.COMMON)
				.food((new FoodProperties.Builder()).nutrition(-1000).saturationMod(-1000f)

						.build()));
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 32;
	}

	@Override
	public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
		return -0.2F;
	}
}
