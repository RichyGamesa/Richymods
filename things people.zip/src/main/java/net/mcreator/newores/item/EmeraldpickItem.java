
package net.mcreator.newores.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item;

import net.mcreator.newores.init.NewOresModTabs;

public class EmeraldpickItem extends PickaxeItem {
	public EmeraldpickItem() {
		super(new Tier() {
			public int getUses() {
				return 6666;
			}

			public float getSpeed() {
				return 12.5f;
			}

			public float getAttackDamageBonus() {
				return 2.5f;
			}

			public int getLevel() {
				return 1;
			}

			public int getEnchantmentValue() {
				return 2;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.EMPTY;
			}
		}, 1, 0f, new Item.Properties().tab(NewOresModTabs.TAB_SSSSS));
	}
}
