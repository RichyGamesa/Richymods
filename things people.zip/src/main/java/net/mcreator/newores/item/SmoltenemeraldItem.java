
package net.mcreator.newores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.newores.init.NewOresModTabs;
import net.mcreator.newores.init.NewOresModFluids;

public class SmoltenemeraldItem extends BucketItem {
	public SmoltenemeraldItem() {
		super(NewOresModFluids.SMOLTENEMERALD,
				new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.RARE).tab(NewOresModTabs.TAB_SSSSS));
	}
}
